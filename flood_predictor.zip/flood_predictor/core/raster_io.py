# -*- coding: utf-8 -*-
"""
raster_io.py

Thin GDAL wrappers for reading rasters into numpy arrays (with their
georeferencing) and writing numpy arrays back out as GeoTIFFs. Runs inside
QGIS's bundled GDAL/Python environment.
"""

import numpy as np
from osgeo import gdal, osr

gdal.UseExceptions()

WGS84_WKT = osr.SpatialReference()
WGS84_WKT.ImportFromEPSG(4326)
WGS84_WKT = WGS84_WKT.ExportToWkt()


def read_raster_as_array(path, band=1):
    """Read a single band of a raster as a numpy array with its georeferencing."""
    ds = gdal.Open(path, gdal.GA_ReadOnly)
    if ds is None:
        raise IOError(f"Could not open raster: {path}")
    band_obj = ds.GetRasterBand(band)
    array = band_obj.ReadAsArray().astype(np.float64)
    nodata = band_obj.GetNoDataValue()
    geotransform = ds.GetGeoTransform()
    projection = ds.GetProjection()
    ds = None
    return array, geotransform, projection, nodata


def write_geotiff(path, array, geotransform, projection, nodata=None, dtype=None):
    """Write a 2D numpy array to a single-band GeoTIFF."""
    if dtype is None:
        dtype = gdal.GDT_Float32

    rows, cols = array.shape
    driver = gdal.GetDriverByName("GTiff")
    ds = driver.Create(path, cols, rows, 1, dtype, options=["COMPRESS=LZW", "TILED=YES"])
    ds.SetGeoTransform(geotransform)
    ds.SetProjection(projection)

    band = ds.GetRasterBand(1)
    out_array = array.copy()
    if nodata is not None:
        out_array = np.where(np.isnan(out_array), nodata, out_array)
        band.SetNoDataValue(float(nodata))
    band.WriteArray(out_array)
    band.FlushCache()
    ds = None


def array_to_memory_dataset(array, geotransform, projection, dtype=gdal.GDT_Byte):
    """Create an in-memory (MEM driver) GDAL dataset from a numpy array --
    used as an intermediate step before polygonizing, without writing to disk."""
    rows, cols = array.shape
    mem_driver = gdal.GetDriverByName("MEM")
    ds = mem_driver.Create("", cols, rows, 1, dtype)
    ds.SetGeoTransform(geotransform)
    ds.SetProjection(projection)
    ds.GetRasterBand(1).WriteArray(array)
    return ds


def reproject_and_align(src_path, ref_geotransform, ref_projection, ref_shape,
                         resample_alg=gdal.GRA_Bilinear):
    """
    Warp/resample a source raster (e.g. a Green or NIR band from a different
    source/grid) onto the exact grid of a reference raster (typically the
    fetched DEM), so that pixel-by-pixel NDWI/seed operations line up.

    Returns a numpy array matching ref_shape.
    """
    rows, cols = ref_shape
    west = ref_geotransform[0]
    north = ref_geotransform[3]
    px_w = ref_geotransform[1]
    px_h = ref_geotransform[5]  # negative
    east = west + cols * px_w
    south = north + rows * px_h

    warp_options = gdal.WarpOptions(
        format="MEM",
        outputBounds=(west, south, east, north),
        width=cols,
        height=rows,
        dstSRS=ref_projection,
        resampleAlg=resample_alg,
    )
    warped_ds = gdal.Warp("", src_path, options=warp_options)
    if warped_ds is None:
        raise IOError(f"Failed to reproject/align raster: {src_path}")
    array = warped_ds.GetRasterBand(1).ReadAsArray().astype(np.float64)
    warped_ds = None
    return array


def rasterize_vector_to_grid(vector_path, ref_geotransform, ref_projection, ref_shape,
                              burn_value=1, layer_name=None):
    """
    Rasterize a vector layer (e.g. a known river centreline or water-body
    polygon layer, possibly in a different CRS) onto the exact grid of a
    reference raster (typically the fetched DEM). Used as an alternative
    seed-mask source to NDWI thresholding.

    Returns a numpy uint8 array matching ref_shape, `burn_value` where
    features are present, 0 elsewhere.
    """
    vt_kwargs = dict(format="Memory", dstSRS=ref_projection)
    if layer_name:
        vt_kwargs["layerName"] = layer_name
    reprojected_ds = gdal.VectorTranslate("", vector_path, **vt_kwargs)
    if reprojected_ds is None:
        raise IOError(f"Failed to read/reproject vector layer: {vector_path}")

    rows, cols = ref_shape
    mem_raster = gdal.GetDriverByName("MEM").Create("", cols, rows, 1, gdal.GDT_Byte)
    mem_raster.SetGeoTransform(ref_geotransform)
    mem_raster.SetProjection(ref_projection)

    layer = reprojected_ds.GetLayer(0)
    gdal.RasterizeLayer(mem_raster, [1], layer, burn_values=[burn_value])

    array = mem_raster.GetRasterBand(1).ReadAsArray()
    mem_raster = None
    reprojected_ds = None
    return array
