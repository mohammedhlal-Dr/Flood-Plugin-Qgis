# -*- coding: utf-8 -*-
"""
dem_fetcher.py

Fetches open elevation data from the AWS Open Data "Terrain Tiles" bucket
(Terrarium PNG encoding) and mosaics it into a single georeferenced DEM
array covering a requested bounding box.

No API key is required; the bucket is public. See:
https://registry.opendata.aws/terrain-tiles/
https://www.mapzen.com/blog/terrain-tile-service/
"""

import io
import uuid
import numpy as np

from .tile_math import tiles_for_bbox, num2deg, TILE_SIZE

TERRARIUM_URL_TEMPLATE = "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"


class DemFetchError(Exception):
    pass


def decode_terrarium(rgb_array):
    """
    Decode a Terrarium-encoded RGB image array into elevation values (metres).

    Terrarium encoding:
        elevation = (R * 256 + G + B / 256) - 32768

    Args:
        rgb_array: numpy array of shape (H, W, 3) or (H, W, 4), dtype uint8

    Returns:
        numpy float32 array of shape (H, W), elevation in metres
    """
    r = rgb_array[..., 0].astype(np.float64)
    g = rgb_array[..., 1].astype(np.float64)
    b = rgb_array[..., 2].astype(np.float64)
    elevation = (r * 256.0 + g + b / 256.0) - 32768.0
    return elevation.astype(np.float32)


def _download_bytes(url, timeout=15):
    """Download raw bytes using only the Python standard library (no
    `requests` dependency, since it is not guaranteed to be present in
    QGIS's bundled Python on every platform)."""
    import urllib.request
    import urllib.error

    req = urllib.request.Request(url, headers={"User-Agent": "QGIS-FloodPredictor-Plugin/1.2.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read(), resp.getcode()
    except urllib.error.HTTPError as e:
        return b"", e.code
    except urllib.error.URLError as e:
        raise DemFetchError(f"Network error fetching {url}: {e.reason}")


def _decode_png_bytes(png_bytes):
    """
    Decode PNG bytes into an (H, W, 3) uint8 RGB array using GDAL's PNG
    driver via an in-memory virtual file (/vsimem). GDAL is always present
    inside QGIS, unlike third-party imaging libraries (Pillow), so this
    avoids an extra dependency that may not be installed.
    """
    from osgeo import gdal

    vsi_path = f"/vsimem/tile_{uuid.uuid4().hex}.png"
    gdal.FileFromMemBuffer(vsi_path, png_bytes)
    try:
        ds = gdal.Open(vsi_path)
        if ds is None:
            raise DemFetchError("Could not decode PNG tile data (GDAL PNG driver returned None).")
        n_bands = ds.RasterCount
        bands = [ds.GetRasterBand(i + 1).ReadAsArray() for i in range(min(3, n_bands))]
        ds = None
    finally:
        gdal.Unlink(vsi_path)

    return np.stack(bands, axis=-1).astype(np.uint8)


def _fetch_single_tile(z, x, y, session=None, timeout=15):
    """Download and decode a single Terrarium tile. Returns a (256, 256) float32 array."""
    # The tile scheme wraps in x but not in y; guard against negative/out-of-range
    n = 2 ** z
    x = x % n
    if y < 0 or y >= n:
        # No data at this row (poles) -- return flat sea-level tile
        return np.zeros((TILE_SIZE, TILE_SIZE), dtype=np.float32)

    url = TERRARIUM_URL_TEMPLATE.format(z=z, x=x, y=y)
    content, status = _download_bytes(url, timeout=timeout)
    if status != 200:
        raise DemFetchError(f"Failed to fetch DEM tile {z}/{x}/{y}: HTTP {status}")

    rgb = _decode_png_bytes(content)
    return decode_terrarium(rgb)


def fetch_dem_for_bbox(min_lon, min_lat, max_lon, max_lat, zoom, progress_cb=None):
    """
    Download and mosaic Terrarium DEM tiles covering the given WGS84 bounding box.

    Args:
        min_lon, min_lat, max_lon, max_lat: bounding box in EPSG:4326 degrees
        zoom: slippy-map zoom level (roughly: 10 ~ 150m/px, 12 ~ 40m/px, 14 ~ 10m/px)
        progress_cb: optional callable(fraction_done: float, message: str);
                     return False from it to request cancellation

    Returns:
        dem: numpy float32 array (rows, cols) of elevation in metres
        geotransform: GDAL-style 6-tuple (originX, pixelW, 0, originY, 0, -pixelH)
                      in EPSG:4326 degrees, ready to write with GDAL
    """
    tiles, mosaic_bounds, n_cols, n_rows, x_min, y_min = tiles_for_bbox(
        min_lon, min_lat, max_lon, max_lat, zoom
    )

    if n_cols * n_rows > 400:
        raise DemFetchError(
            f"Requested area needs {n_cols * n_rows} DEM tiles at zoom {zoom}; "
            f"reduce the study area or lower the zoom level (max 400 tiles)."
        )

    mosaic = np.zeros((n_rows * TILE_SIZE, n_cols * TILE_SIZE), dtype=np.float32)

    total = len(tiles)
    for i, (x, y) in enumerate(tiles):
        tile_arr = _fetch_single_tile(zoom, x, y)
        row = y - y_min
        col = x - x_min
        r0, r1 = row * TILE_SIZE, (row + 1) * TILE_SIZE
        c0, c1 = col * TILE_SIZE, (col + 1) * TILE_SIZE
        mosaic[r0:r1, c0:c1] = tile_arr
        if progress_cb:
            # progress_cb may return False to request cancellation
            if progress_cb((i + 1) / total, f"Downloaded DEM tile {i + 1}/{total}") is False:
                raise DemFetchError("DEM download cancelled by user.")

    west, south, east, north = mosaic_bounds
    px_w = (east - west) / mosaic.shape[1]
    px_h = (north - south) / mosaic.shape[0]
    geotransform = (west, px_w, 0.0, north, 0.0, -px_h)

    # Crop the (slightly oversized, whole-tile) mosaic down to the requested bbox
    dem, geotransform = _crop_to_bbox(mosaic, geotransform, min_lon, min_lat, max_lon, max_lat)

    return dem, geotransform


def _crop_to_bbox(array, geotransform, min_lon, min_lat, max_lon, max_lat):
    """Crop a mosaicked array + geotransform down to the exact requested bbox."""
    west, px_w, _, north, _, px_h_neg = geotransform
    px_h = -px_h_neg

    col_start = max(0, int((min_lon - west) / px_w))
    col_end = min(array.shape[1], int(np.ceil((max_lon - west) / px_w)))
    row_start = max(0, int((north - max_lat) / px_h))
    row_end = min(array.shape[0], int(np.ceil((north - min_lat) / px_h)))

    cropped = array[row_start:row_end, col_start:col_end]
    new_west = west + col_start * px_w
    new_north = north - row_start * px_h
    new_geotransform = (new_west, px_w, 0.0, new_north, 0.0, -px_h)
    return cropped, new_geotransform
