# -*- coding: utf-8 -*-
"""
ndwi.py

Normalized Difference Water Index (McFeeters, 1996):

    NDWI = (Green - NIR) / (Green + NIR)

Used here to derive "water seed" pixels for the inundation model -- i.e.
cells that are already water in the reference imagery, which act as the
starting points that the connectivity-constrained flood fill grows outward
from.
"""

import numpy as np


def compute_ndwi(green, nir, nodata_value=None):
    """
    Compute NDWI from co-registered Green and NIR bands (same shape/grid).

    Args:
        green, nir: 2D numpy arrays, same shape
        nodata_value: optional value in either band to mask out (-> NaN)

    Returns:
        ndwi: 2D numpy float32 array in [-1, 1], NaN where undefined/nodata
    """
    green = green.astype(np.float64)
    nir = nir.astype(np.float64)

    denom = green + nir
    with np.errstate(divide="ignore", invalid="ignore"):
        ndwi = (green - nir) / denom

    ndwi[denom == 0] = np.nan

    if nodata_value is not None:
        ndwi[(green == nodata_value) | (nir == nodata_value)] = np.nan

    return ndwi.astype(np.float32)


def seed_mask_from_ndwi(ndwi, threshold=0.0):
    """
    Threshold an NDWI array into a boolean water-seed mask.

    Args:
        ndwi: 2D numpy array (NaN allowed)
        threshold: NDWI values > threshold are classed as water.
                   0.0 is the standard McFeeters cut-off; slightly negative
                   thresholds (e.g. -0.1) can help pick up narrow/shallow
                   channels that are otherwise missed.

    Returns:
        boolean mask, True = water seed
    """
    return np.nan_to_num(ndwi, nan=-1.0) > threshold


def seed_mask_from_binary_raster(raster_array, water_value=1):
    """
    Build a seed mask directly from an existing binary/classified raster
    (e.g. a pre-computed NDWI mask, a JRC Global Surface Water layer, or a
    rasterised "known river centreline" layer) rather than raw Green/NIR
    bands. Provided as an alternative entry point for users who already
    have a water mask.
    """
    return raster_array == water_value
