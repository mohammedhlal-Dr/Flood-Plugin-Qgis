# -*- coding: utf-8 -*-
"""
inundation.py

Connectivity-constrained planar-fill inundation model.

Method
------
This is a simplified, geometric ("bathtub") flood extent estimator -- not a
hydrodynamic model. It answers: "if the water surface near the seeded water
bodies rose by `depth` metres, which cells would be inundated, given that
water can only reach a cell by a connected path of cells at or below that
water surface?"

Steps:
    1. The DEM should already be depression-filled (see depression_fill.py)
       so that small pits / mosaic artefacts don't spuriously block or
       isolate connectivity.
    2. A reference water-surface elevation is derived from the seed cells
       (the water pixels identified by NDWI thresholding, or supplied
       directly). By default this is the median elevation of the seed
       cells; the target planar water level is then:

            target_level = seed_reference_elevation + flood_depth

    3. All cells with elevation <= target_level form a candidate "wet"
       mask. Connected-component labelling (4- or 8-connectivity) is run
       over this candidate mask, and only components that actually contain
       at least one seed cell are kept -- this is the "connectivity
       constraint": a low-lying but hydraulically disconnected depression
       elsewhere in the raster is correctly excluded, even though its
       elevation alone would qualify it.
    4. Optionally, a flood-depth raster is derived as
       (target_level - filled_dem), masked to the flooded cells, giving a
       simple depth-of-inundation product in addition to the binary extent.

This mirrors common "planar bathtub + hydraulic connectivity" approaches
used for fast, first-pass flood susceptibility screening; it is not a
substitute for a full 1D/2D hydraulic model where flow routing, discharge,
and time-dependence matter.
"""

import numpy as np


def _multi_source_flood_fill(candidate_mask, seed_mask, connectivity=8):
    """
    Grow a region outward from `seed_mask`, restricted to cells where
    `candidate_mask` is True, using iterative vectorized dilation (no scipy
    dependency -- only numpy array shifts, since QGIS's bundled Python does
    not always ship scipy).

    This is equivalent to: label connected components of `candidate_mask`
    and keep only the components that contain a seed -- but computed
    directly via wavefront expansion instead of full-image labelling.
    """
    flooded = seed_mask & candidate_mask
    rows, cols = flooded.shape
    max_iterations = rows + cols  # a flood front can never need more steps than this

    for _ in range(max_iterations):
        dil = flooded.copy()
        dil[1:, :] |= flooded[:-1, :]
        dil[:-1, :] |= flooded[1:, :]
        dil[:, 1:] |= flooded[:, :-1]
        dil[:, :-1] |= flooded[:, 1:]
        if connectivity == 8:
            dil[1:, 1:] |= flooded[:-1, :-1]
            dil[1:, :-1] |= flooded[:-1, 1:]
            dil[:-1, 1:] |= flooded[1:, :-1]
            dil[:-1, :-1] |= flooded[1:, 1:]

        dil &= candidate_mask

        if np.array_equal(dil, flooded):
            break
        flooded = dil

    return flooded


def reference_water_level(filled_dem, seed_mask, method="median"):
    """Derive the reference elevation of the seeded water bodies."""
    seed_elevations = filled_dem[seed_mask]
    if seed_elevations.size == 0:
        raise ValueError("No seed cells found -- check the NDWI threshold or seed input layer.")
    if method == "median":
        return float(np.median(seed_elevations))
    elif method == "min":
        return float(np.min(seed_elevations))
    elif method == "mean":
        return float(np.mean(seed_elevations))
    else:
        raise ValueError("method must be 'median', 'min', or 'mean'")


def run_inundation(filled_dem, seed_mask, flood_depth, connectivity=8,
                    reference_method="median", nodata_mask=None):
    """
    Run the connectivity-constrained planar-fill inundation model for a
    single flood depth.

    Args:
        filled_dem: 2D numpy array, depression-filled DEM (metres)
        seed_mask: 2D boolean numpy array, True where water is already
                   present (from NDWI thresholding or a supplied layer)
        flood_depth: metres of rise above the reference water level
        connectivity: 4 or 8
        reference_method: how to summarise seed elevations ('median','min','mean')
        nodata_mask: optional boolean array of cells to always exclude

    Returns:
        dict with:
            'flood_mask'   : boolean array, True = inundated
            'depth_raster' : float array, flood depth per cell (NaN outside mask)
            'target_level' : the planar water-surface elevation used (metres)
            'reference_level': the seed reference elevation (metres)
    """
    filled_dem = np.asarray(filled_dem, dtype=np.float64)
    seed_mask = np.asarray(seed_mask, dtype=bool)

    ref_level = reference_water_level(filled_dem, seed_mask, reference_method)
    target_level = ref_level + float(flood_depth)

    candidate = filled_dem <= target_level
    if nodata_mask is not None:
        candidate &= ~nodata_mask

    if connectivity not in (4, 8):
        raise ValueError("connectivity must be 4 or 8")

    flood_mask = _multi_source_flood_fill(candidate, seed_mask, connectivity)

    depth_raster = np.full(filled_dem.shape, np.nan, dtype=np.float32)
    depth_raster[flood_mask] = (target_level - filled_dem[flood_mask]).astype(np.float32)

    return {
        "flood_mask": flood_mask,
        "depth_raster": depth_raster,
        "target_level": target_level,
        "reference_level": ref_level,
    }


def run_inundation_multi_depth(filled_dem, seed_mask, flood_depths, connectivity=8,
                                reference_method="median", nodata_mask=None):
    """
    Run the model for several flood depths (e.g. [0.5, 1, 2, 5] m), useful
    for producing a set of scenario extents from one DEM/seed pair.

    Returns:
        dict[depth] -> result dict (see run_inundation), plus a combined
        'max_extent_class' raster where each flooded cell holds the *smallest*
        tested depth at which it becomes inundated (a simple "flood staging" map).
    """
    results = {}
    sorted_depths = sorted(flood_depths)
    staging = np.zeros(filled_dem.shape, dtype=np.float32)  # 0 = never flooded

    for depth in sorted_depths:
        res = run_inundation(filled_dem, seed_mask, depth, connectivity,
                              reference_method, nodata_mask)
        results[depth] = res
        newly_flooded = res["flood_mask"] & (staging == 0)
        staging[newly_flooded] = depth

    results["staging_raster"] = staging
    return results
