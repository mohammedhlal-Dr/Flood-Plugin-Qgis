# -*- coding: utf-8 -*-
"""
exporter.py

Export the inundation model's outputs as:
    - raster (GeoTIFF): the binary flood mask, and/or the flood-depth raster
    - vector (Shapefile): the flood extent polygon(s), via GDAL Polygonize
"""

import numpy as np
from osgeo import gdal, ogr, osr

from .raster_io import write_geotiff, array_to_memory_dataset

gdal.UseExceptions()
ogr.UseExceptions()


def export_flood_raster(out_path, flood_mask, geotransform, projection, depth_raster=None):
    """
    Write the flood result as a GeoTIFF.

    If depth_raster is provided, the output stores flood depth in metres
    (NoData = -9999 outside the flooded area). Otherwise a simple 0/1 binary
    mask is written.
    """
    if depth_raster is not None:
        array = depth_raster.copy()
        write_geotiff(out_path, array, geotransform, projection, nodata=-9999.0,
                      dtype=gdal.GDT_Float32)
    else:
        array = flood_mask.astype(np.uint8)
        write_geotiff(out_path, array, geotransform, projection, nodata=255,
                      dtype=gdal.GDT_Byte)


def export_flood_vector(out_path, flood_mask, geotransform, projection, layer_name="flood_extent"):
    """
    Polygonize the boolean flood mask and write only the "flooded=1"
    polygons out to an ESRI Shapefile.
    """
    mask_uint8 = flood_mask.astype(np.uint8)
    src_ds = array_to_memory_dataset(mask_uint8, geotransform, projection, dtype=gdal.GDT_Byte)
    src_band = src_ds.GetRasterBand(1)

    driver = ogr.GetDriverByName("ESRI Shapefile")
    if driver is None:
        raise RuntimeError("ESRI Shapefile OGR driver not available.")

    # Remove any pre-existing shapefile with the same name (all sidecar files)
    if driver.TestCapability(ogr.ODrCDeleteDataSource):
        try:
            driver.DeleteDataSource(out_path)
        except Exception:
            pass

    out_ds = driver.CreateDataSource(out_path)
    srs = osr.SpatialReference()
    srs.ImportFromWkt(projection)

    out_layer = out_ds.CreateLayer(layer_name, srs=srs, geom_type=ogr.wkbPolygon)
    field_defn = ogr.FieldDefn("flooded", ogr.OFTInteger)
    out_layer.CreateField(field_defn)

    gdal.Polygonize(src_band, src_band, out_layer, 0, [], callback=None)

    # Keep only polygons where flooded == 1 (Polygonize also emits the
    # background 0-value region as a polygon, which we don't want)
    out_layer.SetAttributeFilter("flooded = 0")
    for feat in out_layer:
        out_layer.DeleteFeature(feat.GetFID())
    out_layer.SetAttributeFilter(None)

    out_ds.ExecuteSQL(f"REPACK {layer_name}")
    out_ds = None
    src_ds = None
