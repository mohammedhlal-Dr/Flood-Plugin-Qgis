# -*- coding: utf-8 -*-
"""
depression_fill.py

Depression-fill preprocessing for a DEM, using the Priority-Flood algorithm
(Barnes, Lehman & Mulla, 2014 -- "Priority-flood: An optimal depression-filling
and watershed-labeling algorithm for digital elevation models").

This removes spurious pits/sinks (common in tile-mosaicked, coarse open DEMs)
that would otherwise break hydraulic connectivity in the downstream
inundation model -- e.g. a single noisy low pixel that isn't really a closed
basin, but which would locally disconnect the flood-fill.

The algorithm guarantees the output DEM is "flow-resolvable": every cell has
a monotonically non-increasing path to the raster boundary (or to NoData).
"""

import heapq
import numpy as np


def fill_depressions(dem, nodata=None):
    """
    Fill depressions in a DEM using Priority-Flood.

    Args:
        dem: 2D numpy array (rows, cols) of elevation values
        nodata: value to treat as NoData / permanently open boundary (optional)

    Returns:
        filled: 2D numpy float64 array, same shape, depressions filled
    """
    dem = np.asarray(dem, dtype=np.float64)
    rows, cols = dem.shape

    filled = np.full_like(dem, np.inf)
    visited = np.zeros((rows, cols), dtype=bool)

    if nodata is not None:
        nodata_mask = dem == nodata
    else:
        nodata_mask = np.zeros((rows, cols), dtype=bool)

    heap = []
    counter = 0  # tie-breaker so heap never compares arrays

    def push(r, c, elev):
        nonlocal counter
        heapq.heappush(heap, (elev, counter, r, c))
        counter += 1

    # Seed the priority queue with the raster boundary (open edges) and any
    # NoData cells (treated as spillways -- water can always escape there).
    for r in range(rows):
        for c in (0, cols - 1):
            if not visited[r, c]:
                visited[r, c] = True
                filled[r, c] = dem[r, c]
                push(r, c, dem[r, c])
    for c in range(cols):
        for r in (0, rows - 1):
            if not visited[r, c]:
                visited[r, c] = True
                filled[r, c] = dem[r, c]
                push(r, c, dem[r, c])

    neighbours = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    while heap:
        elev, _, r, c = heapq.heappop(heap)
        for dr, dc in neighbours:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and not visited[nr, nc]:
                visited[nr, nc] = True
                if nodata_mask[nr, nc]:
                    # NoData acts as an open boundary: don't raise it, and let
                    # water drain through it (don't propagate a filled level).
                    filled[nr, nc] = dem[nr, nc]
                    push(nr, nc, elev)
                else:
                    new_elev = max(dem[nr, nc], elev)
                    filled[nr, nc] = new_elev
                    push(nr, nc, new_elev)

    return filled
