# Core algorithmic modules for the Flood Predictor QGIS plugin.
# These modules are pure numpy/scipy/GDAL and have no dependency on
# qgis.core / PyQt5, so they can be unit-tested outside of QGIS.
