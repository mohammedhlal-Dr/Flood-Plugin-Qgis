# -*- coding: utf-8 -*-
"""
tile_math.py

Slippy-map (XYZ) tile math used to work out which AWS Terrain Tile
(Terrarium encoding) images cover a given geographic bounding box, at a
given zoom level, and where each tile sits in geographic space.

Reference: https://www.mapzen.com/blog/terrain-tile-service/
AWS Open Data bucket: https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png
"""

import math

TILE_SIZE = 256  # pixels, standard for terrarium tiles


def deg2num(lat_deg, lon_deg, zoom):
    """Convert lat/lon (EPSG:4326, degrees) to slippy-map tile x/y at a zoom level."""
    lat_rad = math.radians(lat_deg)
    n = 2.0 ** zoom
    xtile = (lon_deg + 180.0) / 360.0 * n
    ytile = (1.0 - math.log(math.tan(lat_rad) + (1.0 / math.cos(lat_rad))) / math.pi) / 2.0 * n
    return xtile, ytile


def num2deg(xtile, ytile, zoom):
    """Convert slippy-map tile x/y (can be fractional) at a zoom level to the
    lat/lon (EPSG:4326) of that point (top-left corner convention)."""
    n = 2.0 ** zoom
    lon_deg = xtile / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * ytile / n)))
    lat_deg = math.degrees(lat_rad)
    return lat_deg, lon_deg


def tiles_for_bbox(min_lon, min_lat, max_lon, max_lat, zoom):
    """
    Work out which integer tile (x, y) indices at `zoom` intersect the given
    bounding box (EPSG:4326), and the geographic bounds of the resulting
    tile mosaic (which will usually be slightly larger than the requested
    bbox, since it snaps to whole tiles).

    Returns:
        tiles: sorted list of (x, y) tuples, row-major (y ascending, x ascending)
        mosaic_bounds: (west, south, east, north) of the full tile mosaic
        n_cols, n_rows: mosaic dimensions in tiles
    """
    # Clamp latitude to the Web Mercator valid range to avoid math domain errors
    max_lat = min(max_lat, 85.05112878)
    min_lat = max(min_lat, -85.05112878)

    x_min_f, y_min_f = deg2num(max_lat, min_lon, zoom)  # top-left
    x_max_f, y_max_f = deg2num(min_lat, max_lon, zoom)  # bottom-right

    x_min = int(math.floor(x_min_f))
    x_max = int(math.floor(x_max_f))
    y_min = int(math.floor(y_min_f))
    y_max = int(math.floor(y_max_f))

    if x_max < x_min:
        x_min, x_max = x_max, x_min
    if y_max < y_min:
        y_min, y_max = y_max, y_min

    tiles = [(x, y) for y in range(y_min, y_max + 1) for x in range(x_min, x_max + 1)]

    north, west = num2deg(x_min, y_min, zoom)
    south, east = num2deg(x_max + 1, y_max + 1, zoom)

    n_cols = x_max - x_min + 1
    n_rows = y_max - y_min + 1

    return tiles, (west, south, east, north), n_cols, n_rows, x_min, y_min


def estimate_tile_count(min_lon, min_lat, max_lon, max_lat, zoom):
    """Quick helper so the UI can warn the user before an over-large download."""
    tiles, _, n_cols, n_rows, _, _ = tiles_for_bbox(min_lon, min_lat, max_lon, max_lat, zoom)
    return len(tiles), n_cols, n_rows
