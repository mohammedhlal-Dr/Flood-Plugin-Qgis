# -*- coding: utf-8 -*-
"""
flood_predictor.py

Main plugin class. Registers a toolbar button / menu entry under
Plugins > Flood Predictor, and opens the FloodPredictorDialog on demand.
"""

import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon


class FloodPredictorPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "&Flood Predictor"
        self.toolbar = self.iface.addToolBar("Flood Predictor")
        self.toolbar.setObjectName("FloodPredictorToolbar")
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icons", "icon.png")
        action = QAction(QIcon(icon_path), "Flood Predictor", self.iface.mainWindow())
        action.triggered.connect(self.run)
        action.setEnabled(True)

        self.toolbar.addAction(action)
        self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        # Lazy import: keeps PyQGIS/PyQt5 imports out of anything that might
        # get imported for standalone testing of the core/ package.
        from .flood_predictor_dialog import FloodPredictorDialog

        if self.dialog is None:
            self.dialog = FloodPredictorDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
