# -*- coding: utf-8 -*-
"""
tasks.py

QgsTask wrapper that runs the whole Flood Predictor pipeline (DEM fetch ->
depression fill -> seed mask -> inundation model -> export) on a background
thread, so QGIS's UI doesn't freeze during DEM download / processing.
"""

import os
import traceback

from qgis.core import QgsTask
from osgeo import gdal

from .core import dem_fetcher, depression_fill, ndwi, inundation, raster_io, exporter

PLUGIN_BUILD = "1.2.1 (dependency-free: no PIL/requests/scipy)"


class FloodPredictorTask(QgsTask):

    def __init__(self, params):
        super().__init__("Flood Predictor", QgsTask.CanCancel)
        self.params = params
        self.log_lines = []
        self.exception = None
        self.output_paths = []  # list of (path, display_name, kind) kind in {'raster','vector'}

    def _log(self, msg):
        self.log_lines.append(msg)

    def _dem_progress(self, fraction, message):
        # DEM download occupies the first 40% of the overall progress bar
        self.setProgress(fraction * 40.0)
        self._log(message)
        if self.isCanceled():
            return False
        return True

    def run(self):
        try:
            self._log(f"Flood Predictor build: {PLUGIN_BUILD}")
            self._log(f"Loaded dem_fetcher from: {dem_fetcher.__file__}")

            p = self.params
            min_lon, min_lat, max_lon, max_lat = p["bbox"]

            self._log(f"Fetching DEM tiles (zoom {p['zoom']}) for bbox "
                       f"({min_lon:.4f}, {min_lat:.4f}, {max_lon:.4f}, {max_lat:.4f})...")
            dem, geotransform = dem_fetcher.fetch_dem_for_bbox(
                min_lon, min_lat, max_lon, max_lat, p["zoom"], progress_cb=self._dem_progress
            )
            projection = raster_io.WGS84_WKT
            if self.isCanceled():
                return False
            self.setProgress(45)

            if p.get("apply_depression_fill", True):
                self._log("Filling DEM depressions (Priority-Flood)...")
                filled_dem = depression_fill.fill_depressions(dem)
            else:
                filled_dem = dem
            self.setProgress(55)
            if self.isCanceled():
                return False

            seed_mask = self._build_seed_mask(dem, geotransform, projection)
            self.setProgress(65)
            if self.isCanceled():
                return False

            flood_depths = p["flood_depths"]
            self._log(f"Running connectivity-constrained inundation model for depths: {flood_depths} m ...")
            results = inundation.run_inundation_multi_depth(
                filled_dem, seed_mask, flood_depths,
                connectivity=p.get("connectivity", 8),
                reference_method=p.get("reference_method", "median"),
            )
            self.setProgress(85)
            if self.isCanceled():
                return False

            self._export_outputs(results, geotransform, projection, flood_depths)
            self.setProgress(100)
            return True

        except Exception as e:
            self.exception = f"{e}\n\n{traceback.format_exc()}"
            return False

    def _build_seed_mask(self, dem, geotransform, projection):
        p = self.params
        mode = p["seed_mode"]

        if mode == "ndwi":
            self._log("Reading and aligning Green/NIR bands, computing NDWI...")
            green = raster_io.reproject_and_align(p["green_path"], geotransform, projection, dem.shape)
            nir = raster_io.reproject_and_align(p["nir_path"], geotransform, projection, dem.shape)
            ndwi_arr = ndwi.compute_ndwi(green, nir)
            return ndwi.seed_mask_from_ndwi(ndwi_arr, threshold=p.get("ndwi_threshold", 0.0))

        elif mode == "raster":
            self._log("Reading and aligning existing water raster mask...")
            aligned = raster_io.reproject_and_align(
                p["water_raster_path"], geotransform, projection, dem.shape,
                resample_alg=gdal.GRA_NearestNeighbour
            )
            return ndwi.seed_mask_from_binary_raster(aligned, water_value=p.get("water_raster_value", 1))

        elif mode == "vector":
            self._log("Rasterizing water/river vector layer onto the DEM grid...")
            arr = raster_io.rasterize_vector_to_grid(
                p["water_vector_path"], geotransform, projection, dem.shape,
                burn_value=1, layer_name=p.get("water_vector_layername")
            )
            return arr == 1

        else:
            raise ValueError(f"Unknown seed_mode: {mode}")

    def _export_outputs(self, results, geotransform, projection, flood_depths):
        p = self.params
        multi = len(flood_depths) > 1

        for depth in flood_depths:
            res = results[depth]
            suffix = f"_{depth}m" if multi else ""

            if p.get("export_extent_raster_path"):
                out_path = self._suffixed_path(p["export_extent_raster_path"], suffix)
                self._log(f"Writing flood extent raster: {out_path}")
                exporter.export_flood_raster(out_path, res["flood_mask"], geotransform, projection)
                self.output_paths.append((out_path, f"Flood extent {depth}m", "raster"))

            if p.get("export_depth_raster_path"):
                out_path = self._suffixed_path(p["export_depth_raster_path"], suffix)
                self._log(f"Writing flood depth raster: {out_path}")
                exporter.export_flood_raster(out_path, res["flood_mask"], geotransform, projection,
                                              depth_raster=res["depth_raster"])
                self.output_paths.append((out_path, f"Flood depth {depth}m", "raster"))

            if p.get("export_vector_path"):
                out_path = self._suffixed_path(p["export_vector_path"], suffix)
                self._log(f"Writing flood extent vector: {out_path}")
                exporter.export_flood_vector(out_path, res["flood_mask"], geotransform, projection,
                                              layer_name=f"flood_extent{suffix}")
                self.output_paths.append((out_path, f"Flood extent polygons {depth}m", "vector"))

        if multi and p.get("export_extent_raster_path"):
            staging_path = self._suffixed_path(p["export_extent_raster_path"], "_staging")
            self._log(f"Writing multi-depth flood staging raster: {staging_path}")
            exporter.export_flood_raster(staging_path, results["staging_raster"] > 0,
                                          geotransform, projection, depth_raster=results["staging_raster"])
            self.output_paths.append((staging_path, "Flood staging (min depth to flood)", "raster"))

    @staticmethod
    def _suffixed_path(path, suffix):
        if not suffix:
            return path
        root, ext = os.path.splitext(path)
        return f"{root}{suffix}{ext}"

    def finished(self, result):
        # Runs on the main thread once run() completes -- safe to touch QGIS API here.
        pass
