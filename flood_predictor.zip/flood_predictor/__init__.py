# -*- coding: utf-8 -*-
"""
Flood Predictor
===============
QGIS plugin entry point. QGIS calls classFactory(iface) to instantiate the
plugin when it is loaded.
"""


def classFactory(iface):
    from .flood_predictor import FloodPredictorPlugin
    return FloodPredictorPlugin(iface)
