# -*- coding: utf-8 -*-
"""
flood_predictor_dialog.py

The plugin's main dialog: study-area selection, water-seed source, model
parameters, and output export options. Runs the pipeline via a background
QgsTask (see tasks.py) so QGIS stays responsive.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QLabel,
    QLineEdit, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox,
    QProgressBar, QPlainTextEdit, QFileDialog, QStackedWidget, QWidget,
    QMessageBox
)

from qgis.core import (
    QgsProject, QgsMapLayerProxyModel, QgsCoordinateTransform,
    QgsCoordinateReferenceSystem, QgsRasterLayer, QgsVectorLayer, QgsApplication
)
from qgis.gui import QgsMapLayerComboBox

from .tasks import FloodPredictorTask
from .core.tile_math import estimate_tile_count

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class FloodPredictorDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.current_task = None

        self.setWindowTitle("Flood Predictor v1.2.0")
        self.setMinimumWidth(520)

        root = QVBoxLayout(self)
        root.addWidget(self._build_extent_group())
        root.addWidget(self._build_seed_group())
        root.addWidget(self._build_model_group())
        root.addWidget(self._build_output_group())

        self.progress_bar = QProgressBar()
        root.addWidget(self.progress_bar)

        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFixedHeight(120)
        root.addWidget(self.log_view)

        button_row = QHBoxLayout()
        self.run_button = QPushButton("Run")
        self.run_button.clicked.connect(self._on_run_clicked)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self._on_cancel_clicked)
        self.cancel_button.setEnabled(False)
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        button_row.addWidget(self.run_button)
        button_row.addWidget(self.cancel_button)
        button_row.addStretch()
        button_row.addWidget(close_button)
        root.addLayout(button_row)

    # ------------------------------------------------------------------ #
    # UI construction
    # ------------------------------------------------------------------ #

    def _build_extent_group(self):
        group = QGroupBox("Study Area (bounding box, WGS84 degrees)")
        form = QFormLayout()

        self.min_lon_edit = QLineEdit()
        self.min_lat_edit = QLineEdit()
        self.max_lon_edit = QLineEdit()
        self.max_lat_edit = QLineEdit()
        for edit, label in [
            (self.min_lon_edit, "Min longitude:"), (self.min_lat_edit, "Min latitude:"),
            (self.max_lon_edit, "Max longitude:"), (self.max_lat_edit, "Max latitude:")
        ]:
            edit.textChanged.connect(self._update_tile_estimate)
            form.addRow(label, edit)

        use_canvas_btn = QPushButton("Use Current Canvas Extent")
        use_canvas_btn.clicked.connect(self._use_canvas_extent)
        form.addRow(use_canvas_btn)

        self.zoom_spin = QSpinBox()
        self.zoom_spin.setRange(1, 15)
        self.zoom_spin.setValue(12)
        self.zoom_spin.valueChanged.connect(self._update_tile_estimate)
        form.addRow("DEM zoom level (higher = finer resolution, slower):", self.zoom_spin)

        self.tile_estimate_label = QLabel("Tiles to download: -")
        form.addRow(self.tile_estimate_label)

        group.setLayout(form)
        return group

    def _build_seed_group(self):
        group = QGroupBox("Water Seeding (starting points for the flood fill)")
        outer = QVBoxLayout()

        self.seed_mode_combo = QComboBox()
        self.seed_mode_combo.addItems([
            "NDWI from Green/NIR raster bands",
            "Existing water raster mask",
            "Existing water vector layer (river/lake)"
        ])
        self.seed_mode_combo.currentIndexChanged.connect(self._on_seed_mode_changed)
        outer.addWidget(self.seed_mode_combo)

        self.seed_stack = QStackedWidget()

        # Page 0: NDWI
        ndwi_page = QWidget()
        ndwi_form = QFormLayout(ndwi_page)
        self.green_combo = QgsMapLayerComboBox()
        self.green_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.nir_combo = QgsMapLayerComboBox()
        self.nir_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.ndwi_threshold_spin = QDoubleSpinBox()
        self.ndwi_threshold_spin.setRange(-1.0, 1.0)
        self.ndwi_threshold_spin.setSingleStep(0.05)
        self.ndwi_threshold_spin.setValue(0.0)
        ndwi_form.addRow("Green band raster:", self.green_combo)
        ndwi_form.addRow("NIR band raster:", self.nir_combo)
        ndwi_form.addRow("NDWI threshold (>  = water):", self.ndwi_threshold_spin)
        self.seed_stack.addWidget(ndwi_page)

        # Page 1: existing raster mask
        raster_page = QWidget()
        raster_form = QFormLayout(raster_page)
        self.water_raster_combo = QgsMapLayerComboBox()
        self.water_raster_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.water_value_spin = QSpinBox()
        self.water_value_spin.setRange(0, 255)
        self.water_value_spin.setValue(1)
        raster_form.addRow("Water raster layer:", self.water_raster_combo)
        raster_form.addRow("Pixel value meaning 'water':", self.water_value_spin)
        self.seed_stack.addWidget(raster_page)

        # Page 2: vector layer
        vector_page = QWidget()
        vector_form = QFormLayout(vector_page)
        self.water_vector_combo = QgsMapLayerComboBox()
        self.water_vector_combo.setFilters(QgsMapLayerProxyModel.VectorLayer)
        vector_form.addRow("Water/river vector layer:", self.water_vector_combo)
        self.seed_stack.addWidget(vector_page)

        outer.addWidget(self.seed_stack)
        group.setLayout(outer)
        return group

    def _build_model_group(self):
        group = QGroupBox("Inundation Model")
        form = QFormLayout()

        self.depths_edit = QLineEdit("1.0")
        self.depths_edit.setToolTip("Comma-separated flood depths in metres above the reference water level, e.g. 0.5,1,2")
        form.addRow("Flood depth(s) (m):", self.depths_edit)

        self.connectivity_combo = QComboBox()
        self.connectivity_combo.addItems(["8 (diagonal + orthogonal)", "4 (orthogonal only)"])
        form.addRow("Connectivity:", self.connectivity_combo)

        self.reference_combo = QComboBox()
        self.reference_combo.addItems(["median", "min", "mean"])
        form.addRow("Seed reference level:", self.reference_combo)

        self.depression_fill_check = QCheckBox("Apply depression-fill preprocessing (recommended)")
        self.depression_fill_check.setChecked(True)
        form.addRow(self.depression_fill_check)

        group.setLayout(form)
        return group

    def _build_output_group(self):
        group = QGroupBox("Outputs")
        form = QFormLayout()

        self.export_extent_check, self.extent_path_edit = self._add_output_row(
            form, "Flood extent raster (GeoTIFF):", "*.tif")
        self.export_depth_check, self.depth_path_edit = self._add_output_row(
            form, "Flood depth raster (GeoTIFF):", "*.tif")
        self.export_vector_check, self.vector_path_edit = self._add_output_row(
            form, "Flood extent vector (Shapefile):", "*.shp")

        group.setLayout(form)
        return group

    def _add_output_row(self, form, label, file_filter):
        row = QHBoxLayout()
        check = QCheckBox()
        path_edit = QLineEdit()
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(lambda: self._browse_save_path(path_edit, file_filter))
        row.addWidget(check)
        row.addWidget(path_edit)
        row.addWidget(browse_btn)
        container = QWidget()
        container.setLayout(row)
        form.addRow(label, container)
        return check, path_edit

    # ------------------------------------------------------------------ #
    # Interaction handlers
    # ------------------------------------------------------------------ #

    def _on_seed_mode_changed(self, index):
        self.seed_stack.setCurrentIndex(index)

    def _use_canvas_extent(self):
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()
        canvas_crs = canvas.mapSettings().destinationCrs()
        if canvas_crs != WGS84:
            transform = QgsCoordinateTransform(canvas_crs, WGS84, QgsProject.instance())
            extent = transform.transformBoundingBox(extent)

        self.min_lon_edit.setText(f"{extent.xMinimum():.6f}")
        self.min_lat_edit.setText(f"{extent.yMinimum():.6f}")
        self.max_lon_edit.setText(f"{extent.xMaximum():.6f}")
        self.max_lat_edit.setText(f"{extent.yMaximum():.6f}")

    def _update_tile_estimate(self, *args):
        try:
            min_lon = float(self.min_lon_edit.text())
            min_lat = float(self.min_lat_edit.text())
            max_lon = float(self.max_lon_edit.text())
            max_lat = float(self.max_lat_edit.text())
            zoom = self.zoom_spin.value()
            count, ncols, nrows = estimate_tile_count(min_lon, min_lat, max_lon, max_lat, zoom)
            self.tile_estimate_label.setText(f"Tiles to download: {count} ({ncols} x {nrows})")
        except (ValueError, Exception):
            self.tile_estimate_label.setText("Tiles to download: -")

    def _browse_save_path(self, path_edit, file_filter):
        path, _ = QFileDialog.getSaveFileName(self, "Choose output path", "", file_filter)
        if path:
            path_edit.setText(path)

    def _on_cancel_clicked(self):
        if self.current_task is not None:
            self.current_task.cancel()

    # ------------------------------------------------------------------ #
    # Run pipeline
    # ------------------------------------------------------------------ #

    def _collect_params(self):
        try:
            bbox = (
                float(self.min_lon_edit.text()), float(self.min_lat_edit.text()),
                float(self.max_lon_edit.text()), float(self.max_lat_edit.text())
            )
        except ValueError:
            raise ValueError("Please enter a valid numeric bounding box (or use 'Use Current Canvas Extent').")

        try:
            flood_depths = [float(d.strip()) for d in self.depths_edit.text().split(",") if d.strip()]
        except ValueError:
            raise ValueError("Flood depth(s) must be a comma-separated list of numbers, e.g. 0.5,1,2")
        if not flood_depths:
            raise ValueError("Please enter at least one flood depth.")

        seed_index = self.seed_mode_combo.currentIndex()
        params = {
            "bbox": bbox,
            "zoom": self.zoom_spin.value(),
            "flood_depths": flood_depths,
            "connectivity": 8 if self.connectivity_combo.currentIndex() == 0 else 4,
            "reference_method": self.reference_combo.currentText(),
            "apply_depression_fill": self.depression_fill_check.isChecked(),
        }

        if seed_index == 0:
            green_layer = self.green_combo.currentLayer()
            nir_layer = self.nir_combo.currentLayer()
            if green_layer is None or nir_layer is None:
                raise ValueError("Please select both a Green band raster and a NIR band raster.")
            params["seed_mode"] = "ndwi"
            params["green_path"] = green_layer.source()
            params["nir_path"] = nir_layer.source()
            params["ndwi_threshold"] = self.ndwi_threshold_spin.value()

        elif seed_index == 1:
            water_layer = self.water_raster_combo.currentLayer()
            if water_layer is None:
                raise ValueError("Please select a water raster layer.")
            params["seed_mode"] = "raster"
            params["water_raster_path"] = water_layer.source()
            params["water_raster_value"] = self.water_value_spin.value()

        else:
            vector_layer = self.water_vector_combo.currentLayer()
            if vector_layer is None:
                raise ValueError("Please select a water/river vector layer.")
            path, layername = self._parse_vector_source(vector_layer.source())
            params["seed_mode"] = "vector"
            params["water_vector_path"] = path
            params["water_vector_layername"] = layername

        if self.export_extent_check.isChecked():
            if not self.extent_path_edit.text():
                raise ValueError("Please choose a path for the flood extent raster, or uncheck it.")
            params["export_extent_raster_path"] = self.extent_path_edit.text()
        if self.export_depth_check.isChecked():
            if not self.depth_path_edit.text():
                raise ValueError("Please choose a path for the flood depth raster, or uncheck it.")
            params["export_depth_raster_path"] = self.depth_path_edit.text()
        if self.export_vector_check.isChecked():
            if not self.vector_path_edit.text():
                raise ValueError("Please choose a path for the flood extent vector, or uncheck it.")
            params["export_vector_path"] = self.vector_path_edit.text()

        if not any(k.startswith("export_") for k in params):
            raise ValueError("Please select at least one output to export.")

        return params

    @staticmethod
    def _parse_vector_source(source):
        """QGIS vector layer source() strings can look like
        '/path/to/file.gpkg|layername=rivers' -- split that out."""
        if "|" in source:
            path, rest = source.split("|", 1)
            layername = None
            for part in rest.split("|"):
                if part.startswith("layername="):
                    layername = part.split("=", 1)[1]
            return path, layername
        return source, None

    def _on_run_clicked(self):
        try:
            params = self._collect_params()
        except ValueError as e:
            QMessageBox.warning(self, "Flood Predictor", str(e))
            return

        self.log_view.clear()
        self.progress_bar.setValue(0)
        self.run_button.setEnabled(False)
        self.cancel_button.setEnabled(True)

        task = FloodPredictorTask(params)
        task.progressChanged.connect(lambda: self.progress_bar.setValue(int(task.progress())))
        task.taskCompleted.connect(lambda: self._on_task_finished(task))
        task.taskTerminated.connect(lambda: self._on_task_finished(task))

        self.current_task = task
        QgsApplication.taskManager().addTask(task)

    def _on_task_finished(self, task):
        self.run_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.log_view.setPlainText("\n".join(task.log_lines))

        if task.exception:
            self.log_view.appendPlainText(f"\nERROR:\n{task.exception}")
            QMessageBox.critical(self, "Flood Predictor", "The flood prediction task failed. See the log for details.")
            self.current_task = None
            return

        if task.isCanceled():
            self.log_view.appendPlainText("\nCancelled by user.")
            self.current_task = None
            return

        for path, name, kind in task.output_paths:
            if kind == "raster":
                layer = QgsRasterLayer(path, name)
            else:
                layer = QgsVectorLayer(path, name, "ogr")
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
            else:
                self.log_view.appendPlainText(f"Warning: could not load output layer '{name}' from {path}")

        self.log_view.appendPlainText("\nDone. Output layers added to the project.")
        self.current_task = None
