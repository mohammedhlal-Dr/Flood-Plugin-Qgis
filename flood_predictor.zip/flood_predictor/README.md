# Flood Predictor — QGIS Plugin (v1.2.0)

Open-source flood inundation modelling plugin for QGIS. It automatically
fetches open elevation data for your study area, conditions it
hydrologically, seeds it with known water pixels, and runs a
connectivity-constrained planar-fill inundation model to estimate flood
extent and depth.

## Pipeline

1. **DEM acquisition** — downloads elevation tiles for the study area
   bounding box from the public AWS "Terrain Tiles" bucket (Terrarium PNG
   encoding, no API key needed) and mosaics them into a single DEM.
2. **Depression-fill preprocessing** — a Priority-Flood algorithm
   (Barnes, Lehman & Mulla, 2014) removes spurious pits/sinks in the DEM
   (common in coarse, tile-mosaicked open elevation data) that would
   otherwise break hydraulic connectivity.
3. **NDWI-based water seeding** — computes the Normalized Difference Water
   Index from user-supplied Green/NIR raster bands (e.g. Sentinel-2,
   Landsat) and thresholds it to identify existing water pixels. An
   existing water raster mask or a river/water vector layer can be used
   instead.
4. **Connectivity-constrained planar-fill inundation model** — grows the
   flood extent outward from the seed pixels up to a target planar water
   level (reference seed elevation + user-specified flood depth),
   restricted to hydraulically connected cells (via connected-component
   labelling), so low-lying but disconnected depressions elsewhere in the
   raster are correctly excluded even though their elevation alone would
   qualify them.
5. **Export** — writes results as GeoTIFF (binary flood extent and/or
   flood depth in metres) and/or Shapefile (flood extent polygons). Supports
   multiple flood-depth scenarios in one run (e.g. `0.5,1,2,5`), plus a
   combined "staging" raster recording the minimum tested depth at which
   each cell becomes inundated.

**This is a simplified, geometric ("bathtub") flood extent estimator, not a
full hydrodynamic model.** It does not solve flow routing, discharge, or
time-dependent hydraulics (e.g. HEC-RAS, LISFLOOD-FP). It is intended for
fast, first-pass flood susceptibility screening and teaching/demonstration
purposes.

## Installation

1. In QGIS: **Plugins → Manage and Install Plugins → Install from ZIP**.
2. Select `flood_predictor.zip`.
3. Enable "Flood Predictor" in the plugin list if it isn't auto-enabled.
4. A new toolbar button and a **Plugins → Flood Predictor** menu entry appear.

### Requirements
- QGIS ≥ 3.16 (uses `QgsTask`, `QgsMapLayerComboBox`)
- Nothing else to install. The plugin deliberately depends only on what
  every QGIS installation already ships: the GDAL/OGR Python bindings,
  PyQt5, `numpy`, and the Python standard library. It does **not** require
  `scipy`, `Pillow`, or `requests` — none of those are guaranteed to be
  present in QGIS's bundled Python on every platform (this is a common
  cause of "plugin fails to load/run" on Windows OSGeo4W-style installs),
  so DEM tile decoding and downloading use GDAL's own PNG driver and
  Python's built-in `urllib` instead, and the flood-fill connectivity
  logic is a hand-written vectorized numpy routine rather than
  `scipy.ndimage.label`.
- An internet connection (to fetch DEM tiles from AWS)

## Usage

1. **Study Area** — enter a WGS84 bounding box, or click
   **Use Current Canvas Extent** to grab it from the map canvas (it is
   reprojected to EPSG:4326 automatically if needed). Choose a DEM zoom
   level (12 is a reasonable default — roughly 20–40 m/pixel depending on
   latitude; higher zoom = finer resolution but more tiles to download).
   The tile-count estimate updates live; requests over 400 tiles are
   rejected to avoid very slow runs — shrink the area or lower the zoom.

2. **Water Seeding** — choose one of:
   - *NDWI from Green/NIR bands*: pick two co-registered raster layers
     (e.g. Sentinel-2 B03/B08) and an NDWI threshold (0.0 is the standard
     McFeeters cut-off).
   - *Existing water raster mask*: any classified raster where a specific
     pixel value denotes water.
   - *Existing water vector layer*: a river/lake layer (points, lines, or
     polygons), rasterized onto the DEM grid automatically.

3. **Inundation Model** — enter one or more flood depths in metres
   (comma-separated, e.g. `0.5,1,2`), connectivity (8- or 4-neighbour),
   how the seed reference elevation is summarised (median/min/mean), and
   whether to apply depression-fill (recommended).

4. **Outputs** — tick and set a path for any combination of: flood extent
   GeoTIFF, flood depth GeoTIFF, and flood extent Shapefile. With multiple
   depths, each output is written per-depth (suffixed `_<depth>m`), plus a
   combined staging raster.

5. Click **Run**. The pipeline executes in the background (QGIS remains
   usable); progress and log messages appear at the bottom of the dialog.
   On completion, output layers are added to the project automatically.

## Known limitations

- The DEM mosaic's georeferencing is derived directly from slippy-map tile
  corner coordinates in WGS84 degrees. This is a standard simplification
  for tile-based DEM tools; at typical flood-mapping zoom levels the
  residual distortion within a single mosaic is small, but for precision
  area/volume calculations, consider reprojecting the exported DEM/results
  into a suitable projected CRS (e.g. UTM) afterwards.
- Green/NIR/water-raster inputs must be file-based raster layers (e.g.
  GeoTIFF) that GDAL can open directly via their `source()` path; some
  in-memory or virtual layer types are not currently supported.
- This is a planar/"bathtub" connectivity model, not a hydrodynamic
  solver — treat outputs as a susceptibility screening tool rather than an
  engineering-grade flood forecast.

## Project layout

```
flood_predictor/
├── __init__.py                # classFactory() entry point
├── metadata.txt                # QGIS plugin metadata
├── flood_predictor.py           # plugin class (toolbar/menu registration)
├── flood_predictor_dialog.py    # UI dialog
├── tasks.py                     # background QgsTask pipeline
├── icons/icon.png
└── core/                        # pure numpy/scipy/GDAL modules (no PyQt5/qgis
    │                             dependency -- unit-testable standalone)
    ├── tile_math.py              # slippy-map tile <-> lon/lat math
    ├── dem_fetcher.py            # AWS Terrarium tile download + mosaic
    ├── depression_fill.py        # Priority-Flood depression filling
    ├── ndwi.py                   # NDWI computation + water-seed thresholding
    ├── inundation.py             # connectivity-constrained planar-fill model
    ├── raster_io.py              # GDAL read/write/align/rasterize helpers
    └── exporter.py                # GeoTIFF + Shapefile export
```

## License

Open-source; adapt the license header of your choice before publishing to
the official QGIS Plugin Repository (e.g. GPLv2+, which is required for
listing on plugins.qgis.org).
